#!/usr/bin/env bash
# Standalone Keepalived setup (no Ansible). RHEL 10, run as root.
set -euo pipefail

usage() {
  cat <<EOF
Usage: sudo $0 [options]

Options:
  --role ROLE             MASTER or BACKUP (sets sensible default priority)
  --interface IFACE       Interface for the VIP (default: eth0)
  --vip IP[,IP...]        Floating virtual IP address(es)
  --priority N            Override VRRP priority (default: MASTER 150 / BACKUP 100)
  --router-id ID          global router_id (default: hostname)
  --auth-pass PASS        VRRP auth password (default: changeMe)
  --vrid ID               VRRP virtual_router_id (default: 51)
  --track-service NAME    Service to track for failover (default: rsyslog)
  --notify-script PATH    Notify script (receives MASTER/BACKUP/FAULT as \$1)
  --help                  Show this help

With no options on an interactive terminal, you are prompted for each value.
EOF
}

[[ ${1:-} == "--help" || ${1:-} == "-h" ]] && { usage; exit 0; }

if [[ $(id -u) -ne 0 ]]; then
  echo "This script must be run as root." >&2
  exit 1
fi

ROLE=BACKUP
INTERFACE=eth0
VIP=192.168.1.100
PRIORITY=
ROUTER_ID=$(hostname -s 2>/dev/null || echo SYSLOG_HA)
AUTH_PASS=changeMe
VRID=51
TRACK_SERVICE=rsyslog
NOTIFY_SCRIPT=
arg_count=$#

prompt() { local __v="$1" __t="$2" __d="$3" __i; read -rp "$__t [$__d]: " __i; eval "$__v=\"${__i:-$__d}\""; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --role)          ROLE=${2^^}; shift 2;;
    --interface)     INTERFACE=$2; shift 2;;
    --vip)           VIP=$2; shift 2;;
    --priority)      PRIORITY=$2; shift 2;;
    --router-id)     ROUTER_ID=$2; shift 2;;
    --auth-pass)     AUTH_PASS=$2; shift 2;;
    --vrid)          VRID=$2; shift 2;;
    --track-service) TRACK_SERVICE=$2; shift 2;;
    --notify-script) NOTIFY_SCRIPT=$2; shift 2;;
    --help|-h)       usage; exit 0;;
    *) echo "Unknown option: $1" >&2; usage; exit 1;;
  esac
done

if [[ "$arg_count" -eq 0 && -t 0 ]]; then
  echo "Interactive Keepalived setup"
  prompt ROLE          "Role (MASTER/BACKUP)"        "$ROLE"
  prompt INTERFACE     "Network interface"           "$INTERFACE"
  prompt VIP           "VIP(s), comma-separated"     "$VIP"
  prompt ROUTER_ID     "router_id"                   "$ROUTER_ID"
  prompt AUTH_PASS     "VRRP auth password"          "$AUTH_PASS"
  prompt VRID          "virtual_router_id"           "$VRID"
  prompt TRACK_SERVICE "Track service (blank=none)"  "$TRACK_SERVICE"
  prompt NOTIFY_SCRIPT "Notify script (blank=none)"  "$NOTIFY_SCRIPT"
  echo
fi

ROLE=${ROLE^^}
[[ "$ROLE" == "MASTER" || "$ROLE" == "BACKUP" ]] || { echo "Role must be MASTER or BACKUP." >&2; exit 1; }
[[ -n "$VIP" ]] || { echo "At least one VIP is required." >&2; exit 1; }
if [[ -z "$PRIORITY" ]]; then
  [[ "$ROLE" == "MASTER" ]] && PRIORITY=150 || PRIORITY=100
fi

if command -v dnf >/dev/null 2>&1; then PKG=dnf
elif command -v yum >/dev/null 2>&1; then PKG=yum
else echo "No dnf/yum found." >&2; exit 1; fi

echo "Installing keepalived..."
$PKG install -y keepalived

mkdir -p /etc/keepalived
chmod 755 /etc/keepalived
CONFIG=/etc/keepalived/keepalived.conf

{
  echo "global_defs {"
  echo "    router_id $ROUTER_ID"
  echo "    enable_script_security"
  echo "    script_user root"
  echo "}"
  echo
  if [[ -n "$TRACK_SERVICE" ]]; then
    cat <<EOF
vrrp_script chk_${TRACK_SERVICE} {
    script "/usr/bin/systemctl is-active --quiet ${TRACK_SERVICE}"
    interval 2
    weight -60
    fall 2
    rise 2
}

EOF
  fi
  cat <<EOF
vrrp_instance VI_1 {
    state $ROLE
    interface $INTERFACE
    virtual_router_id $VRID
    priority $PRIORITY
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass $AUTH_PASS
    }
EOF
  if [[ -n "$TRACK_SERVICE" ]]; then
    echo "    track_script {"
    echo "        chk_${TRACK_SERVICE}"
    echo "    }"
  fi
  echo "    virtual_ipaddress {"
  IFS=',' read -ra VIP_LIST <<< "$VIP"
  for ip in "${VIP_LIST[@]}"; do
    ip="$(echo "$ip" | xargs)"
    [[ -n "$ip" ]] && echo "        $ip"
  done
  echo "    }"
  if [[ -n "$NOTIFY_SCRIPT" ]]; then
    echo "    notify_master \"$NOTIFY_SCRIPT MASTER\""
    echo "    notify_backup \"$NOTIFY_SCRIPT BACKUP\""
    echo "    notify_fault  \"$NOTIFY_SCRIPT FAULT\""
  fi
  echo "}"
} > "$CONFIG"

chmod 644 "$CONFIG"

if command -v keepalived >/dev/null 2>&1; then
  echo "Validating config..."
  keepalived -t -f "$CONFIG"
fi

echo "Enabling and starting keepalived..."
systemctl enable --now keepalived

cat <<EOF
Keepalived configured:
  role/state:        $ROLE
  priority:          $PRIORITY
  interface:         $INTERFACE
  virtual_router_id: $VRID
  router_id:         $ROUTER_ID
  VIP(s):            $VIP
  track service:     ${TRACK_SERVICE:-<none>}
  config:            $CONFIG
EOF
[[ -n "$NOTIFY_SCRIPT" ]] && echo "  notify script:     $NOTIFY_SCRIPT"
