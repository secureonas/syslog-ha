#!/usr/bin/env bash
# One-click: install Ansible, collect Keepalived settings, run the playbook.
# RHEL 10, run as root.
set -euo pipefail

if [[ $(id -u) -ne 0 ]]; then
  echo "This script must be run as root." >&2
  exit 1
fi

if [[ ! -f "$(pwd)/playbook.yml" ]]; then
  echo "Run this script from the repository root (where playbook.yml lives)." >&2
  exit 1
fi

# --- sanity: RHEL family --------------------------------------------------
if [[ -r /etc/os-release ]]; then
  . /etc/os-release
  case "${ID:-} ${ID_LIKE:-}" in
    *rhel*|*fedora*) : ;;
    *) echo "Warning: this does not look like a RHEL-family host (ID=${ID:-?})." ;;
  esac
fi

if command -v dnf >/dev/null 2>&1; then
  PKG=dnf
elif command -v yum >/dev/null 2>&1; then
  PKG=yum
else
  echo "No dnf/yum found. RHEL/Oracle Linux required." >&2
  exit 1
fi

prompt() {  # prompt VAR "text" "default"
  local __var="$1" __txt="$2" __def="$3" __in
  read -rp "$__txt [$__def]: " __in
  printf -v "$__var" '%s' "${__in:-$__def}"
}

install_ansible() {
  if command -v ansible-playbook >/dev/null 2>&1; then
    echo "Ansible already installed."
    return
  fi
  echo "Installing Ansible via $PKG..."
  $PKG install -y ansible-core || $PKG install -y ansible || {
    echo "Repo install failed; trying EPEL..."
    $PKG install -y epel-release || true
    $PKG install -y ansible-core || $PKG install -y ansible || {
      echo "Falling back to pip..."
      $PKG install -y python3-pip
      python3 -m pip install --upgrade pip
      python3 -m pip install ansible-core
    }
  }
}

cat <<'EOF'
This will:
  1) install Ansible locally
  2) collect Keepalived settings
  3) run the playbook to configure rsyslog (TLS + logrotate) and Keepalived
     with SELinux permissive and the firewall disabled.
EOF
echo

# --- syslog only? ---------------------------------------------------------
WANT_KA=yes
prompt WANT_KA "Configure Keepalived too? (yes/no)" "$WANT_KA"

install_ansible

if [[ "${WANT_KA,,}" != "yes" && "${WANT_KA,,}" != "y" ]]; then
  echo "Running syslog only..."
  ANSIBLE_FORCE_COLOR=1 ansible-playbook -i inventory/hosts.ini playbook.yml --tags syslog
  echo "Done."
  exit 0
fi

# --- keepalived settings --------------------------------------------------
ROLE=BACKUP
INTERFACE=eth0
VIPS=192.168.1.100
VRID=51
ROUTER_ID=$(hostname -s 2>/dev/null || echo SYSLOG_HA)
AUTH_PASS=changeMe
NOTIFY_SCRIPT=

prompt ROLE          "Preferred role (MASTER=holds VIP normally / BACKUP)" "$ROLE"
prompt INTERFACE     "Network interface for the VIP"          "$INTERFACE"
prompt VIPS          "Floating VIP(s), comma-separated"       "$VIPS"
prompt VRID          "VRRP virtual_router_id (1-255)"         "$VRID"
prompt ROUTER_ID     "Keepalived router_id"                   "$ROUTER_ID"
prompt AUTH_PASS     "VRRP auth password"                     "$AUTH_PASS"
prompt NOTIFY_SCRIPT "Notify script path (blank = none)"      "$NOTIFY_SCRIPT"

ROLE=${ROLE^^}
if [[ "$ROLE" != "MASTER" && "$ROLE" != "BACKUP" ]]; then
  echo "Role must be MASTER or BACKUP." >&2
  exit 1
fi

# Build a JSON array of VIPs for --extra-vars.
IFS=',' read -ra _vips <<< "$VIPS"
vip_json=""
for v in "${_vips[@]}"; do
  v="$(echo "$v" | xargs)"   # trim
  [[ -z "$v" ]] && continue
  vip_json+="\"$v\","
done
vip_json="[${vip_json%,}]"

EXTRA=$(cat <<JSON
{"keepalived_role":"$ROLE","keepalived_interface":"$INTERFACE","keepalived_virtual_ips":$vip_json,"keepalived_vrid":$VRID,"keepalived_router_id":"$ROUTER_ID","keepalived_auth_pass":"$AUTH_PASS","keepalived_notify_script":"$NOTIFY_SCRIPT"}
JSON
)

echo
echo "Running playbook..."
ANSIBLE_FORCE_COLOR=1 ansible-playbook -i inventory/hosts.ini playbook.yml --extra-vars "$EXTRA"
echo "Bootstrap complete."
